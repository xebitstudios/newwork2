## Agentic AI Crash Course using Langgraph

### Setup Instructions
1. Rename sample.env to .env file and add your keys. You can find the instructions on key generation through the YouTube video on codebasics channel
2. Follow YouTube video instructions to install uv, PyCharm pro and other packages


