from fastapi import FastAPI, HTTPException, Depends, status
from pydantic import BaseModel
from typing import List
from datetime import datetime, UTC
from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, Session


# Database setup
SQLALCHEMY_DATABASE_URL = "sqlite:///./twitter_clone.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class PostDB(Base):
    __tablename__ = "posts"

    id = Column(Integer, primary_key=True, index=True)
    content = Column(String)
    created_at = Column(DateTime, default=lambda: datetime.now(UTC))
    comments = relationship("CommentDB", back_populates="post")

class CommentDB(Base):
    __tablename__ = "comments"

    id = Column(Integer, primary_key=True, index=True)
    content = Column(String)
    created_at = Column(DateTime, default=lambda: datetime.now(UTC))
    post_id = Column(Integer, ForeignKey("posts.id"))
    post = relationship("PostDB", back_populates="comments")

# Create tables
Base.metadata.create_all(bind=engine)


app = FastAPI()

class PostBase(BaseModel):
    content: str

class Post(PostBase):
    id: int
    created_at: datetime
    
    class Config:
        orm_mode = True

class CommentBase(BaseModel):
    content: str

class Comment(CommentBase):
    id: int
    created_at: datetime
    post_id: int

    class Config:
        orm_mode = True

@app.post("/posts", status_code=status.HTTP_201_CREATED, response_model=Post)
async def create_post(post: PostBase, db: Session = Depends(get_db)):
    new_post = PostDB(**post.dict())
    db.add(new_post)
    db.commit()
    db.refresh(new_post)
    return new_post

@app.get("/posts", response_model=List[Post])
async def get_posts(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    posts = db.query(PostDB).offset(skip).limit(limit).all()
    return posts

@app.get("/posts/{post_id}", response_model=Post)
async def get_post(post_id: int, db: Session = Depends(get_db)):
    post = db.query(PostDB).filter(PostDB.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    return post

@app.post("/posts/{post_id}/comments", status_code=status.HTTP_201_CREATED, response_model=Comment)
async def create_comment(post_id: int, comment: CommentBase, db: Session = Depends(get_db)):
    post = db.query(PostDB).filter(PostDB.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    new_comment = CommentDB(**comment.model_dump(), post_id=post_id)
    db.add(new_comment)
    db.commit()
    db.refresh(new_comment)
    return new_comment

@app.get("/posts/{post_id}/comments", response_model=List[Comment])
async def get_comments(post_id: int, skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    comments = db.query(CommentDB).filter(CommentDB.post_id == post_id).offset(skip).limit(limit).all()
    return comments

@app.get("/posts/{post_id}/posts-and-comments")
async def get_posts_and_comments(post_id: int, db: Session = Depends(get_db)):
    post = db.query(PostDB).filter(PostDB.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    comments = db.query(CommentDB).filter(CommentDB.post_id == post_id).all()
    return {"post": post, "comments": comments}


@app.delete("/posts/{post_id}/comments", status_code=status.HTTP_204_NO_CONTENT)
async def delete_all_comments(post_id: int, db: Session = Depends(get_db)):
    post = db.query(PostDB).filter(PostDB.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    db.query(CommentDB).filter(CommentDB.post_id == post_id).delete()
    db.commit()
    
    return None


