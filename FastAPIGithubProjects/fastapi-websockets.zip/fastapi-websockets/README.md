Much of this code came from: https://fastapi.tiangolo.com/advanced/websockets/
