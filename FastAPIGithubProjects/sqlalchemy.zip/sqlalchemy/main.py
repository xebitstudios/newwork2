# Import necessary modules
from sqlalchemy import Column, Integer, String, ForeignKey, Sequence, create_engine
from sqlalchemy.orm import sessionmaker, relationship, declarative_base

# Create an engine (connection to the database)
engine = create_engine('sqlite:///orm.db')
# engine = create_engine('sqlite:///orm.db', echo=True)

# Create a session (used to interact with the database)
Session = sessionmaker(bind=engine)
session = Session()

# Create a base class for declarative class definitions
Base = declarative_base()

# Define the User model
class User(Base):
    __tablename__ = 'users'  # Name of the table in the database
    id = Column(Integer, Sequence('user_id_seq'), primary_key=True)  # Primary Key
    name = Column(String(50))  # Name column
    email = Column(String(50))  # Email column

    # Relationship to the Post model, setting up a one-to-many relationship
    posts = relationship('Post', back_populates='user')

# Define the Post model
class Post(Base):
    __tablename__ = 'posts'  # Name of the table in the database
    id = Column(Integer, primary_key=True)  # Primary Key
    title = Column(String(100))  # Title column
    content = Column(String)  # Content column
    user_id = Column(Integer, ForeignKey('users.id'))  # Foreign Key linking to the User table

    # Relationship to the User model, completing the one-to-many relationship
    user = relationship('User', back_populates='posts')

# Create all tables in the database (if they don't already exist)
Base.metadata.create_all(engine)

# Adding sample data
user1 = User(name='Alice', email='alice@example.com')
user2 = User(name='Bob', email='bob@example.com')
post1 = Post(title='Alice’s First Post', content='This is the content of Alice’s first post.', user=user1)
post2 = Post(title='Alice’s Second Post', content='This is the content of Alice’s second post.', user=user1)
post3 = Post(title='Bob’s First Post', content='This is the content of Bob’s first post.', user=user2)

# Add the users and posts to the session and commit them to the database
session.add_all([user1, user2, post1, post2, post3])
session.commit()

# Query to join the Post and User tables and retrieve posts with their authors
posts_with_users = session.query(Post, User).join(User).all()

# Print out each post's title and the name of the author
for post, user in posts_with_users:
    print(f"Post: {post.title}, Author: {user.name}")

# Query to retrieve posts authored by 'Alice'
alice = session.query(User).filter_by(name='Alice').first()
for post in alice.posts:
    print(f"Title: {post.title}, Content: {post.content}")

# Advanced query: Joining Post and User tables and filtering posts authored by 'Alice'
filtered_posts = session.query(Post).join(User).filter(User.name == 'Alice').all()

# Print out filtered posts
for post in filtered_posts:
    print(f"Title: {post.title}, Author: {post.user.name}")
    
    
# Update: Changing the title of one of Alice's posts
post_to_update = session.query(Post).filter_by(title="Alice’s First Post").first()
if post_to_update:
    post_to_update.title = "Alice’s Updated First Post"
    session.add(post_to_update)
    session.commit()
    session.refresh(post_to_update)
    print(f"Updated Post: {post_to_update.title}")

# Delete: Removing Bob's first post
post_to_delete = session.query(Post).filter_by(title="Bob’s First Post").first()
if post_to_delete:
    session.delete(post_to_delete)
    session.commit()
    # session.refresh(post_to_delete)
    print(f"Deleted Post titled: 'Bob’s First Post'")