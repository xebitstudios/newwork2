# Youtube-FastAPI-Part1
## Get Started Downloads : Requirements

1. **pip install fastapi**
2. **pip install uvicorn**
3. **pip install sqlalchemy**

**Must have SQLite3 Install on machine**

## To run app

**uvicorn books:app --reload**

## URL
**127.0.0.1:8000/docs**
