from typing import Annotated
from fastapi import Depends, FastAPI

app = FastAPI()

class EmailService:
    def send_email(self, recipient: str, message: str):
        print(f"Sending email to {recipient}: {message}")

# @app.post("/send-email/")
# def send_email(recipient: str, message: str):
#     # Directly creating the EmailService instance inside the route
#     email_service = EmailService()
#     email_service.send_email(recipient, message)
#     return {"status": "Email sent"}

# Dependency function
def get_email_service():
    return EmailService()

email_service_dependency = Annotated[EmailService, Depends(get_email_service)]

@app.post("/send-email/")
def send_email(recipient: str, message: str, email_service: email_service_dependency):
    email_service.send_email(recipient, message)
    return {"status": "Email sent"}