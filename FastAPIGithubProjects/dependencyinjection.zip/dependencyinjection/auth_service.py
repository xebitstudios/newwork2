from typing import Annotated
from fastapi import Depends, FastAPI, HTTPException

app = FastAPI()

class AuthService:
    def authenticate(self, token: str):
        if token == "valid-token":
            return True
        else:
            raise HTTPException(status_code=401, detail="Unauthorized")

# @app.get("/secure-data/")
# def get_secure_data(token: str):
#     # Directly creating the AuthService instance inside the route
#     auth_service = AuthService()
#     if auth_service.authenticate(token):
#         return {"data": "This is secure data"}

# Dependency function
def get_auth_service():
    return AuthService()

auth_service_dependency = Annotated[AuthService, Depends(get_auth_service)]

@app.get("/secure-data/")
def get_secure_data(token: str, auth_service: auth_service_dependency):
    if auth_service.authenticate(token):
        return {"data": "This is secure data"}