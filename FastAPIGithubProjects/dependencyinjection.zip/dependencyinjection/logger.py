from fastapi import FastAPI, Depends
from typing import Annotated

app = FastAPI()

class Logger:
    def log(self, message: str):
        print(f"Logging message: {message}")

# @app.get("/log/{message}")
# def log_message(message: str):
#     # Directly creating the Logger instance inside the route
#     logger = Logger()
#     logger.log(message)
#     return {"message_logged": message}

# Dependency function
def get_logger():
    return Logger()

logger_dependency = Annotated[Logger, Depends(get_logger)]

@app.get("/log/{message}")
                              # logger: Logger = Depends(get_logger)
def log_message(message: str, logger: logger_dependency):
    logger.log(message)
    return{"message_logged": message}