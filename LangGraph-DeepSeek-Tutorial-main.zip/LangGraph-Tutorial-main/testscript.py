x = 2
y = "test"
print(str(x) + y)
