def main():
    print("Hello from graphrag-chat!")


if __name__ == "__main__":
    main()
